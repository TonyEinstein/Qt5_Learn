class SI:
    mainWin = None
    loginWin = None